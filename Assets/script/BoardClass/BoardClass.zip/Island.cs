﻿using UnityEngine;
using System.Collections;

public class Island : MonoBehaviour
{
    protected VirtualTileMap _VTileMap;
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
}
